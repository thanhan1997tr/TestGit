/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thuong
 */
public class SinhVien {
    private String MSSV;
    private String HoTen;
    private int NamSinh;
    
    //Construtor no para
    //duoc goi khi ? SinhVien sv = new SinhVien();
    public SinhVien(){
        MSSV = "57130423";
        HoTen = "Vu Thi Thuong";
        NamSinh = 1997;
    }
    
    //Construtor with para
    //duoc goi khi ? SinhVien sv = new SinhVien("57130424", "Vu Thi Thuong", 1997);
    public SinhVien(String MSSV, String HoTen, int NamSinh){
        this.MSSV = MSSV;
        this.HoTen = HoTen;
        this.NamSinh = NamSinh;
    }

    /**
     * @return the MSSV
     */
    public String getMSSV() {
        return MSSV;
    }

    /**
     * @param MSSV the MSSV to set
     */
    public void setMSSV(String MSSV) {
        this.MSSV = MSSV;
    }
    
    public String getHoTen(){
        return MSSV;
    }
    
    public void setHoTen(String HoTen){
        this.HoTen = HoTen;
    }

    /**
     * @return the NamSinh
     */
    public int getNamSinh() {
        return NamSinh;
    }

    /**
     * @param NamSinh the NamSinh to set
     */
    public void setNamSinh(int NamSinh) {
        this.NamSinh = NamSinh;
    }
    
    
}
